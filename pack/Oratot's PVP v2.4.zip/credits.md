# Credits

- Marlow - Vanilla+
- ArshuGamingHY - SideShieldTexturePack
- ioblackshaw (a.k.a Enchanted Games) - Visible Powder Snow
- Zwaluw - Ice Cream

## All Vanilla Tweaks Credits

All packs utilizing vanilla shaders by ShockMicro, Ancientkingg & ioblackshaw

Unique Dyes by MMStinks

Allay Elytra by Ninni

Vex Elytra by The_Khuzdul1

Bushy Leaves by Pollie

Variated Connected Bookshelves by Charlie Nichols

Spinning Skull on Fire Painting by Kristoffer Zetterstrand

Xisuma Turtle by LordCloud147

Wandering Xisuma by Rashaexe

Beeralis by RubikOwl

Smoother Font from Faithful Resource Pack Project

Anti-Alias Font by Zwaluw

MS Painted Font by Stridey

Blocky Font by Ewan Howell

Classic Panorama by sameythehedgie

Smash Enderman (OptiFine model) by Bold Muddy

Most 'Updated Texture' Fix packs by (or based on textures by) Jasper 'JAPPA' Boerstra

Pixel Consistent Ghast from Faithful Resource Pack Project

Pixel Consistent Sonic Boom from Faithful Resource Pack Project

Phantom Rain by ItsChawk
