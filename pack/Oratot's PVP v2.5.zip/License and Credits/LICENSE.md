Oratot's PVP is created and maintained by Oratot.

Do not misrepresent this resource pack or its original contributions
as your own work.

Minecraft and Minecraft-derived assets are owned by Mojang Studios /
Microsoft and are subject to their applicable terms.

Original files independently authored by Oratot,
including Respackopts configuration, are available under the MIT License.

This does not apply to Minecraft-derived assets, Vanilla Tweaks
material, or other third-party material [^1].

See credits.txt

[^1]:
    Vanilla Tweaks and other third-party material remain subject to their
    respective licenses and permissions.

# MIT License

© 2026 ItzOratotITA

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
