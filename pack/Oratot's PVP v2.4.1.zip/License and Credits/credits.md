# Credits

- Marlow - Vanilla+ (literally a single file, small shield)
- ArshuGamingHY - SideShieldTexturePack - © ArshuGamingHY
- ioblackshaw (a.k.a Enchanted Games) - Visible Powder Snow
- Zwaluw - Ice Cream (font)

## Permission

![Zwaluw permission](./zwaluw.avif)

![Enchanted permission](./enchanted.avif)

## All Vanilla Tweaks Credits

Vanilla Tweaks: https://vanillatweaks.net

All packs utilizing vanilla shaders by ShockMicro, Ancientkingg & ioblackshaw

Unique Dyes by MMStinks

Allay Elytra by Ninni

Vex Elytra by The_Khuzdul1

Bushy Leaves by Pollie

Variated Connected Bookshelves by Charlie Nichols

Spinning Skull on Fire Painting by Kristoffer Zetterstrand

Xisuma Turtle by LordCloud147

Wandering Xisuma by Rashaexe

Beeralis by RubikOwl

Smoother Font from Faithful Resource Pack Project

Anti-Alias Font by Zwaluw

MS Painted Font by Stridey

Blocky Font by Ewan Howell

Classic Panorama by sameythehedgie

Smash Enderman (OptiFine model) by Bold Muddy

Most 'Updated Texture' Fix packs by (or based on textures by) Jasper 'JAPPA' Boerstra

Pixel Consistent Ghast from Faithful Resource Pack Project

Pixel Consistent Sonic Boom from Faithful Resource Pack Project

Phantom Rain by ItsChawk

Pumpkin Carving Competition 2025 winners (credits):

1. "Long Boy" (carved_pumpkin_long_boy.png) by Miffen Kops
2. "Hysterical" (carved_pumpkin_hysterical.png) by Samusquinha
3. "Pumpkin #1" (carved_pumpkin_green_guy1.png) by Green Guy
4. "Evil pumpkin guy" (carved_pumpkin_evil.png) by HeyIgna
5. "Mr. Jive" (carved_pumpkin_mr_jive.png) by Shark_cool
6. "Jackenstein" (carved_pumpkin_jackenstein.png) by Squid Eevee
7. "Creeper Pumpkin" (carved_pumpkin_creeper.png) by Spruce Studios
8. "Pumpkin #2" (carved_pumpkin_green_guy2.png) by Green Guy
9. "YOUR TAKING TOO LONG" (carved_pumpkin_taking_too_long.png) by Crackers0106
10. "Orange Cat Activities" (carved_pumpkin_orange_cat_activities.png) by HiperDoble
11. "Happy Ghast" by (carved_pumpkin_happy_ghast.png) Miffen Kops
12. "Unease" (carved_pumpkin_unease.png) by Anirak0
13. "cross eyed" (carved_pumpkin_cross_eyed.png) by Sergkx
14. "Little Angry Guy" (carved_pumpkin_little_angry_guy.png) by Scutoel
15. "Agonizing Guy" (carved_pumpkin_agonizing_guy.png) by HeyIgna
16. "arthropod" (carved_pumpkin_arthropod.png) by Crabbarition
17. "Mischievous smile pumpkin" (carved_pumpkin_mischievous.png) by Uanderson_test3
18. "Goofy Pumpkin" (carved_pumpkin_goofy.png) by Spruce Studios
19. "Fake Angry Pumpkin" (carved_pumpkin_fake_angry.png) by Uanderson_test3
20. "Eeyees" (carved_pumpkin_eeyees.png) by Lilly
21. "Loopy Ghost" (carved_pumpkin_loopy_ghost.png) by anderium
22. "Melting" (carved_pumpkin_melting.png) by Lilly
23. "2" (carved_pumpkin_ioblackshaw2.png) by ioblackshaw
24. "Guardian" (carved_pumpkin_guardian.png) by BetterDonutGalaxy
25. "Surveyor" (carved_pumpkin_surveyor.png) by Lapiz101
